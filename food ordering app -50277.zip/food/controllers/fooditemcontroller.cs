using FoodApp.Data;
using FoodApp.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FoodApp.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class FoodItemsController : ControllerBase
    {
        private readonly FoodItemService service;
        public IConfiguration Configuration { get; }
        public FoodItemsController(IConfiguration configuration)
        {
            Configuration = configuration;
            service = new FoodItemService(configuration);
        }

        [HttpGet]
        public IActionResult Get(int itemId)
        {
            var data = service.GetFood(itemId);
            return Ok(data);
        }

        [HttpGet, Route("all")]
        public IActionResult GetAll(int restaurantId)
        {
            var data = service.Restaurant(restaurantId, false);
            return Ok(data);
        }

        [HttpPost]
        public IActionResult Post(FoodItemVM foodItemVM)
        {
            service.Create(foodItemVM);
            return Ok();
        }

        [HttpPost, Route("update")]
        public IActionResult Update(FoodItemVM foodItemVM)
        {
            service.Update(foodItemVM);
            return Ok();
        }

        [HttpGet, Route("search")]
        [AllowAnonymous]
        public IActionResult Search(string term)
        {
            var data = service.Search(term);
            return Ok(data);
        }
    }
}
