using FoodApp.Data;
using FoodApp.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace FoodApp.API.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	[Authorize]
	public class UserController : ControllerBase
	{
		private readonly UserService userService;
		public IConfiguration Configuration { get; }
		public UserController(IConfiguration configuration)
		{
			Configuration = configuration;
			userService = new UserService(configuration);
		}

		[HttpPost]
		[Route("Login")]
		[AllowAnonymous]
		public IActionResult Login(LoginVM login)
		{
			if (!ModelState.IsValid)
				return BadRequest(ModelState);
			try
			{
				if (userService.Auth(login))
				{
					return Ok(GenerateToken(login.Email));
				}
				else
				{
					return BadRequest(new { invalid_grand = "Invalid username and password" });
				}
			}
			catch (Exception ex)
			{
				return BadRequest(new { error = ex.Message });
			}
		}

		[HttpPost]
		[Route("Register")]
		[AllowAnonymous]
		public IActionResult Register(RegisterVM registerVM)
		{
			if (!ModelState.IsValid)
				return BadRequest(ModelState);
			try
			{
				var user = userService.GetUser(registerVM.Email);
				if (user.Email == null)
				{
					userService.Create(registerVM);
					return Ok("User Created.");
				}
				else
				{
					return BadRequest(new { error = "Email already exist" });
				}
			}
			catch (Exception ex)
			{
				return BadRequest(new { error = ex.Message });
			}
		}

		private TokenVM GenerateToken(string email)
		{
			var user = userService.GetUser(email);
			var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["JwtTokenKey"]));
			var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
			var claims = new List<Claim>
			{
				new Claim(ClaimTypes.Email, user.Email),
				new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())
			};
			claims.Add(new Claim(ClaimTypes.Role, user.Role));

			DateTime expire = DateTime.Now.AddDays(1);
			var token = new JwtSecurityToken(Configuration["JwtTokenIssuer"],
				Configuration["JwtTokenAudience"],
				claims,
				expires: expire,
				signingCredentials: creds
				);
			TokenVM tokenManager = new TokenVM();
			tokenManager.Token = new JwtSecurityTokenHandler().WriteToken(token);
			tokenManager.TokenExpire = expire;
			tokenManager.Role = user.Role;
			tokenManager.Name = user.Name;
			tokenManager.Email = user.Email;

			return tokenManager;
		}

	}
}
