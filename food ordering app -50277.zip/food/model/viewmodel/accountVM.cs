using System.ComponentModel.DataAnnotations;

namespace FoodApp.Models.ViewModels
{
    public class RegisterVM
    {
        [Required(ErrorMessage = "Name is required."),
            MinLength(4, ErrorMessage = "Name must have minimum 4 characters"),
            MaxLength(100, ErrorMessage = "Name must be less than 32 characters")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required."),
            MinLength(8, ErrorMessage = "Email must have minimum 8 characters"),
            MaxLength(50, ErrorMessage = "Email must be less than 50 characters"),
            DataType(DataType.EmailAddress, ErrorMessage = "Please enter valid email format.")]
        public string Email { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Password is required."),
            MinLength(8, ErrorMessage = "Password must have minimum 8 characters"),
            MaxLength(100, ErrorMessage = "Password must be less than 32 characters"),
            DataType(DataType.Password)]
        public string Password { get; set; }
    }

    public class LoginVM
    {
        [Required(ErrorMessage = "Email is required."),
            MinLength(8, ErrorMessage = "Email must have minimum 8 characters"),
            MaxLength(50, ErrorMessage = "Email must be less than 50 characters"),
            DataType(DataType.EmailAddress, ErrorMessage = "Please enter valid email format.")]
        public string Email { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Password is required."),
            MinLength(8, ErrorMessage = "Password must have minimum 8 characters"),
            MaxLength(100, ErrorMessage = "Password must be less than 32 characters"),
            DataType(DataType.Password)]
        public string Password { get; set; }
    }

    public class TokenVM
    {
        public string Email { get; set; }

        public string Token { get; set; }

        public string Name { get; set; }

        public string Role { get; set; }

        public DateTime TokenExpire { get; set; }
    }
}
