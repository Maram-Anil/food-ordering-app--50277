using System.ComponentModel.DataAnnotations;

namespace FoodApp.Models.ViewModels
{
    public class OrderVM
    {
        public int OrderId { get; set; }

        public bool Cancelled { get; set; }

        [Required]
        public DateTime OrderedDateTime { get; set; }

        public string? CancelledDateTime { get; set; }

        public int FoodId { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; }

        [Required, MaxLength(500)]
        public string Description { get; set; }

        [Required]
        public int Price { get; set; }

        public int Discount { get; set; }

        [Required, MaxLength(1000)]
        public string ImageUrl { get; set; }
    }
}
